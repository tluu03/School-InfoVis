To run this visualization:
1. Run a simple server using: python -m http.server 8080
2. Open up http://localhost:8080/
3. Edit the X and Y axis to your selection
4. Edit the filters to your selection based on region
5. Select individual data points(not hover)
6. Click off of the data points to reset your selection
7. Video Link: https://youtu.be/wdJmjvMcs1U
